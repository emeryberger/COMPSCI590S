import java.io.IOException;
import java.io.PrintStream;
import java.util.Collection;
import java.util.LinkedList;


public class WordCount implements Master {
    public WordCount(int workerNum, String[] filenames) throws IOException {

    }

    public void setOutputStream(PrintStream out) {

    }

    public static void main(String[] args) throws Exception {

    }

    public void run() {

    }

    public Collection<Process> getActiveProcess() {
        return new LinkedList<>();
    }

    public void createWorker() throws IOException {

    }
}

